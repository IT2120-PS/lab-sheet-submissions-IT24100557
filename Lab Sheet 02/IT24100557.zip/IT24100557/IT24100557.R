setwd("C:\\Users\\it24100557\\Desktop\\IT24100557")
print(sample(1:3))
print(sample(1:3,size=3,replace=TRUE))
print(sample(c(2,5,3),size=4,replace=FALSE))
print(sample(1:2,size=10,prob=c(0.3,0.7),replace+TRUE))


x<-1:10
m<-sample(x,1)
if(m<=5){
  print("m is less than 5")
}
x<-1:10
y<-sample(x,1)
if(y<=5){
  print("y is less than 5")
}else{
  print("y is greater than 5")
}

j<-1
while(j<10){
  print(j)
}
h<-1
aaa=function(r){
  h<<-h+1
  r<-h+1
  print(r)
}
aaa(3)
x - c(1, 2, 3)
x[1] / x[2]ˆ3 - 1 + 2 * x[3] - x[2 - 1]
vector<-1:15
div_by_3 <- sum(vec%%3==0)
print(div_by_3)






vector<-1:15
div_by_3<-sum(vector%%3==0)
print(div_by_3)









vec<- c(10,2,34,7,25)
max_value <-vec[1]
max_index <- 1

for(i in 2:length(vec)){
  if(vec[i]> max_value){
    max_value <- vec[i]
    max_index <- i 
  }
}
cat("The index of the maximum value is:", max_index, "\n")





vec <- c(10, 2, 34, 7, 25)
max_index <- which.max(vec)
cat("The index of the maximum value is:", max_index, "\n")
