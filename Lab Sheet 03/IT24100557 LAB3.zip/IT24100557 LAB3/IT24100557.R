setwd("C:\\Users\\it24100557\\Desktop\\IT24100557 LAB3")

student_data <- read.csv("Exercise.csv" ,header=TRUE)

summary(student_data$X1)
fix(data)


hist(student_data$X1, 
     main = "Histogram of Age (X1)", 
     xlab = "Age (X1)", 
     col = "lightblue", 
     border = "black")


gender_table <- table(student_data$X2)
print(gender_table)

barplot(gender_table, 
        main = "Bar Chart of Gender (X2)", 
        xlab = "Gender", 
        ylab = "Frequency", 
        col = c("lightblue", "lightgreen"))

boxplot(student_data$X1 ~ student_data$X3, 
        main = "Age (X1) by Accommodation (X3)", 
        xlab = "Accommodation Type (X3)", 
        ylab = "Age (X1)", 
        col = c("lightblue", "lightgreen", "lightyellow"))

anova_result <- aov(X1 ~ X3, data = student_data)
summary(anova_result)
